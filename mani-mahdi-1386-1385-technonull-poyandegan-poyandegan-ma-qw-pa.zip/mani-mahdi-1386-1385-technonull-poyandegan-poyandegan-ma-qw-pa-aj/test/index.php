<?php

$us = $_GET["username"];
echo $us;

?>